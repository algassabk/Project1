package com.acmebank.model;

public enum Role {
    Banker, Customer
}
