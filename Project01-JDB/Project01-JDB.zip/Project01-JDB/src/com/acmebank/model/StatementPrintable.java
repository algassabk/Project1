package com.acmebank.model;
public interface StatementPrintable {
    void printStatement();
}
