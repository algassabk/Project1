package com.acmebank.model;

public enum TransactionType {
    Deposit, Withdraw, Transfer_in, Transfer_out
}
