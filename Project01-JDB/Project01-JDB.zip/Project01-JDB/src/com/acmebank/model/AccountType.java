package com.acmebank.model;

public enum AccountType {
    Checking, Savings
}
